﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T8_JAHR_1145922
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int Numero;
            int Resultado;

            string Binario = "";

            Numero = int.Parse(textBox1.Text);

            while (Numero > 0)
            {
                Resultado = Numero % 2;
                Numero /= 2;

                Binario = Resultado.ToString() + Binario;
            }
            this.label3.Text = Binario;

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int Numero2 = int.Parse(textBox2.Text);

            label6.Text = Convert.ToString(Numero2, 16);
        }
    }
}
