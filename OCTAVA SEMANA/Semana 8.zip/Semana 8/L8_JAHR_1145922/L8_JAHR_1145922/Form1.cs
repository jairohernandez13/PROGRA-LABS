﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L8_JAHR_1145922
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0: tabControl1.SelectedIndex = 0; break;
                case 1: tabControl1.SelectedIndex = 1; break;
                case 2: tabControl1.SelectedIndex = 2; break;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int n = 0, refe;
            n = int.Parse(textBox1.Text);
            refe = n;
            for (int i = 1; i <= refe; i++)
            {
                label3.Text = n.ToString();
                n = n + i;
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 1; i <= 10; i++)
            {
                textBox3.Text += " " + "\r\n";
                for (int j = 1; j <=10; j++)
                {
                    textBox3.AppendText((i * j).ToString() + "\t");
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int contar, suma = 0, numero = int.Parse(label5.Text);
            for (contar = 1; contar < numero; contar++)
            {
                if (numero % contar == 0)
                    suma += contar;
            }
            if (suma == numero)
                label5.Text = "Si es perfecto";
            else
                label5.Text = "No es perfecto";
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}