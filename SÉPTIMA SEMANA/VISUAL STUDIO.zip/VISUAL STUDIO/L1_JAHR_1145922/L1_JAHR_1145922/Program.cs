﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1_JAHR_1145922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hola mundo soy Jairo");
            Console.ReadKey();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy Jairo");

            /*la diferencia entre Writeline, es que, este da el código separado; mientras el Write, muestra el código en conjunto.*/

            Console.Write("Hola Mundo ");
            Console.Write("soy Jairo");

            Console.WriteLine(" Ingrese su nombre: ");
            string Nombre = Console.ReadLine();

            Console.WriteLine("Hola Mundo");
            Console.WriteLine("soy " + Nombre);

            /*la diferencia entre Writeline, es que, este da el código separado; mientras el Write, muestra el código en conjunto.*/

            Console.Write("Hola Mundo ");
            Console.Write("soy " + Nombre);
            Console.ReadKey();
        }
    }
}
