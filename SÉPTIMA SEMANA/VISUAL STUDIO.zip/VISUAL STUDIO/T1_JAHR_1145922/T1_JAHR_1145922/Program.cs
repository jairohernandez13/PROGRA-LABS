﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T1_JAHR_1145922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Mi segundo Programa");
            Console.WriteLine("Ingrese su nombre: ");
            Console.WriteLine("Ingrese su edad: ");
            Console.WriteLine("Ingrese su carrera: ");
            Console.WriteLine("Ingrese su carne: ");

            string Nombre = Console.ReadLine();
            string Edad = Console.ReadLine();
            string Carrera = Console.ReadLine();
            string Carne = Console.ReadLine();

            Console.WriteLine("Nombre: " + Nombre);
            Console.WriteLine("Edad: " + Edad);
            Console.WriteLine("Carrera: " + Carrera);
            Console.WriteLine("Carné: " + Carne);

            Console.WriteLine("Nombre:" + Nombre + " tengo " + Edad + " años y estudio en la carrera de " +Carrera+ " Mi numero de carné es: " + Carne);
            Console.ReadKey();
        }
    }
}
