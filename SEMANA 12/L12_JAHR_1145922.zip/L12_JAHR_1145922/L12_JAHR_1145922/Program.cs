﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_JAHR_1145922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int suma = 0;
            double prom= 0;
            Random num = new Random();

            int[,] matriz = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for(int c = 0; c < 5; c++)
                {
                    matriz[f,c] = num.Next(50);
                    suma = suma + matriz[f,c];
                }
            }
            prom = suma / matriz.Length;
            Console.WriteLine("La suma de la matriz fue de: " + suma);
            Console.WriteLine("El promedio de la matriz es de: " + prom);
            Console.WriteLine("");

            int[,] matriz2 = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz2[f, c] = num.Next(50);
                }
                
            }
            int[,] matriz3 = new int[4, 5];
            for (int f = 0; f < 4; f++)
            {
                for (int c = 0; c < 5; c++)
                {
                    matriz3[f, c] = matriz[f, c] + matriz2[f, c];
                    Console.Write(matriz3[f,c] + " ");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
