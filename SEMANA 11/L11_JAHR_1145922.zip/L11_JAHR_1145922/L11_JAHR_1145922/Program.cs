﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L11_JAHR_1145922
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] secciónA;
            secciónA = new double[6]; 
            double[] secciónB;
            secciónB = new double[6];

            double aprobadosA = 0;
            double aprobadosB = 0;
            double desaprobadosA = 0;
            double desaprobadosB = 0;

            double totalsecciónA = 0;
            double totalsecciónB = 0;

            double porcentajeA, porcentajeB, pordesaprobadoA, pordesaprobadoB, totalporcentajeapro, totalporcentajedesa, promediosecA, promediosecB, totalprom;

            int suma1 = 0;
            int suma2 = 0;
            int suma3 = 0;
            int suma4 = 0;

            int promencima, promdebajo;

            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Ingrese nota del alumno " + (i+1) + " de la Sección A:");
                secciónA[i] = Convert.ToDouble(Console.ReadLine());
            }

            for (int i = 0; i < 6; i++)
            {
                Console.WriteLine("Ingrese notas del alumno " + (i + 1) + " de la Sección B:");
                secciónB[i] = Convert.ToDouble(Console.ReadLine());
            }
            for (int i = 0; i < 6; i++)
            {
                totalsecciónA = totalsecciónA + secciónA[i];
                if (secciónA[i] >= 65)
                {
                    aprobadosA = aprobadosA + secciónA[i];
                }
                else
                {
                    desaprobadosA = desaprobadosA + secciónA[i];
                }
            }
            for (int i = 0; i < 6; i++)
            {
                totalsecciónB = totalsecciónB + secciónB[i];
                if (secciónB[i] >= 65)
                {
                    aprobadosB = aprobadosB + secciónB[i];
                }
                else
                {
                    desaprobadosB = desaprobadosB + secciónB[i];
                }
            }

            porcentajeA = (aprobadosA / totalsecciónA) * 100;
            pordesaprobadoA = (desaprobadosA / totalsecciónA) * 100;
            porcentajeB = (aprobadosB / totalsecciónB) * 100;
            pordesaprobadoB = (aprobadosA / totalsecciónB) * 100;
            totalporcentajeapro = ((aprobadosA + aprobadosB) / (totalsecciónA + totalsecciónB) * 100);
            totalporcentajedesa = ((desaprobadosA + desaprobadosB) / (totalsecciónA + totalsecciónB) * 100);
            promediosecA = totalsecciónA / 5;
            promediosecB = totalsecciónB / 5;
            totalprom = ((promediosecA + promediosecB) / 10);

            Console.WriteLine("El porcentaje de aprobados de la Sección A es de: " + porcentajeA);
            Console.WriteLine("El porcentaje de desaprobados de la Sección A es de: " + pordesaprobadoA);
            Console.WriteLine("El porcentaje de aprobados de la Sección B es: " + porcentajeB);
            Console.WriteLine("El porcentaje de desaprobados de la Sección B es: " + pordesaprobadoB);
            Console.WriteLine("El total de porcentajes desaprobados es: " + totalporcentajedesa);
            Console.WriteLine("El porcentaje total de aprobados es: " + totalporcentajeapro);
            Console.WriteLine("El promedio de la sección A es de: " + promediosecA);
            Console.WriteLine("El promedio de la sección B es de: " + promediosecB);
            Console.WriteLine("El promedio total es de: " + totalprom);

            for (int i = 0; i < 6; i++)
            {
                if (secciónA[i] > 90)
                {
                    suma1++;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (secciónA[i] < 75)
                {
                        suma2++;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (secciónB[i] > 90)
                {
                    suma3++;
                }
            }
            for (int i = 0; i < 6; i++)
            {
                if (secciónA[i] < 75)
                {
                    suma4++;
                }
            }
            promencima = suma1 + suma3;
            promdebajo = suma2 + suma4;
            Console.WriteLine("Los estudiantes que tienen un promedio por encima de 90 es de: " + promencima);
            Console.WriteLine("Los estudiantes que tienen un promedio por debajo de 75 es de: " + promdebajo);
            Console.ReadKey();
        }
    }
}
